#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>

#ifndef _func_h
#define _func_h

#define TMAX 12

////////////////////////////////////////////////////////////////////////////////////////////
/*
void lecture(FILE *fichier, int grille[TMAX][TMAX], int n);
void affichage(int grille[TMAX][TMAX], int n);
void pov(int grille[TMAX], int n, int pdv[]);
bool absent_in_column(int k, int grille[TMAX][TMAX], int j, int n);
bool absent_in_row(int k, int grille[TMAX][TMAX], int i, int n);
void certs(int a, int b, int c, int d, int n, int grille[TMAX][TMAX], int i, int j);
void traitement1(int grille[TMAX][TMAX], int n);
*/
////////////////////////////////////////////////////////////////////////////////////////////

bool is_ligne(int k, int grille[TMAX][TMAX], int i, int n);
bool is_colonne(int k, int grille[TMAX][TMAX], int j, int n);
void remplissage_m(int grille[TMAX][TMAX], int n);
bool verification_t(int grille[TMAX][TMAX], int n);
void remplissage_h(int grille[TMAX][TMAX], int n);
void remplissage_b(int grille[TMAX][TMAX], int n);
void remplissage_g(int grille[TMAX][TMAX], int n);
void remplissage_d(int grille[TMAX][TMAX], int n);
void remplissage_t(int grille[TMAX][TMAX], int n);
void generateur(char n);
#endif