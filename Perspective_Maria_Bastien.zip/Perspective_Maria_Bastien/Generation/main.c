#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Fonctions.h"
#include <stdbool.h>

int main()
{
    char a;
    printf("\nBonjour, vous allez pouvoir générer la grille aléatoire du jeu comprise entre 0 et 9.\n");
    printf("\nATTENTION : LA DIFFICULTÉ ET LE TEMPS POUR GÉNÉRER LA GRILLE EST DÛ AUX CHIFFRES CHOISIS\n");
    printf("\n(Nous recommandons une taille comprise entre 3 et 6)\n");
    printf("\nveuillez saisir un chiffre pour commencer: ");
    scanf("%c", &a);
    generateur(a);
    return 0;
}
