#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#ifndef _func_h
#define _func_h

#define TMAX 720 //( correspendant au nombre de permutations possible a n= 6 , 6!)
#define LMAX 8   //(correspendant a la taille d'une ligne ou d'une colonne (6+2))
/************************************************LECTURE ET AFFICHAGE****************************************************/
void lecture(FILE *fichier, int grille[LMAX][LMAX], int n);
void affichage(int grille[LMAX][LMAX], int n);

/************************************************FONCTIONS NECESSAIRES AU TRAITEMENTS ***********************************/
void pov(int grille[LMAX], int n, int pdv[]);                                        // Pour avoir les point de vue des deux cotés d'une rangé d'immeubles
bool absent_in_column(int k, int grille[LMAX][LMAX], int j, int n);                  // Pour verifier si il n'existe pas deja un immeuble de hauteur h sur une meme colonne
bool absent_in_row(int k, int grille[LMAX][LMAX], int i, int n);                     // Pour verifier si il n'existe pas deja un immeuble de hauteur h sur une meme ligne
void certs(int a, int b, int c, int d, int n, int grille[LMAX][LMAX], int i, int j); // Remplie les certitudes de la grilles pour donner des indices utils au second traitement
/*void print_tab(int tab[], int size_tab);*/

long factorielle(int n);
void combin(int tab[], int i, int size_tab, int *k, int comb[TMAX][TMAX]); // Genere toutes les permutation possible d'une liste de 1 a N
void permute(int tab[], int i, int j);                                     // Pour les permutation de la fonction combin

bool possible(int tab[], int a, int b, int size_tab); // Permet de verifier si il est possible qu'une permutation generée par combin soie dans un ordre qui correspond

void possibilites(int comb[TMAX][TMAX], int pos[TMAX][TMAX], int size_tab, int a, int b); /*Quand a celle-ci , c'est un peu la dernière etape pour avoir les possibilités
                                                                                             compatibles aux pdv de lignes dans un premier temps puis celles des colonnes */

void traitement1(int grille[LMAX][LMAX], int n);                                             // Qui remplie la grille avec les certitudes ( par exemple que devant une pdv=1 c'est necessairement le plus haut donc n)
void traitement2(int grille[LMAX][LMAX], int n, int comb[TMAX][TMAX], int temp[LMAX][LMAX]); // Qui remplie la grille avec ce qu'on a eu comme résultats de selection de possibilités

#endif
