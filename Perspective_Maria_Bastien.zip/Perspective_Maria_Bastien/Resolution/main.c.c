#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Resolution.h"

int main()
{

    int n;
    int comb[TMAX][TMAX];
    int temp[LMAX][LMAX];

    FILE *fichier = NULL;
    int grille[LMAX][LMAX];

    fichier = fopen("./Perspective2.txt", "r");

    if (fichier == NULL)
        exit(1);

    char n1 = getc(fichier);
    n = n1 - '0';

    n = n + 2;
    lecture(fichier, grille, n);
    affichage(grille, n);
    traitement1(grille, n);

    printf("\n\n");

    affichage(grille, n);
    traitement2(grille, n, comb, temp);

    affichage(grille, n);
    fclose(fichier);
    return 0;
}