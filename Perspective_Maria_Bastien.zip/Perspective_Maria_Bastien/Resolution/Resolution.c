#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "Resolution.h"




// FONCTIONS De le Resolution:

/*Cette fonction permet la lecture de fichier tout en remplissant une matrice à deux dimensions tel une copie de la grille en entree
en type int pour le traitement  */

void lecture(FILE *fichier, int grille[LMAX][LMAX], int n)
{
    int i = 0;
    char grille_temporaire[n][n]; // elle permet de copier les informations du fichier dans une premiere grille "temporaire" de type char

    char max_g = n * n;

    while (fgets(grille_temporaire[i], max_g, fichier)) // ici s'effectue donc cette copie et la boucle permet de lire le fichier jusqu'à sa fin
    {
        i++;
    }

    for (int y = 1; y <= n; y++) // le y commence par 1 car la premiere ligne contien le n
    {
        for (int i = 0; i < n; i++)
        {
            if (grille_temporaire[y][i] == 'X')
            {
                grille[y - 1][i] = 0; // remplace les X (comme écrit dans le fichier )
            }
            else if (grille_temporaire[y][i] >= '1')
            {
                grille[y - 1][i] = grille_temporaire[y][i] - '0'; // transformer les chiffres de char en int
            }
            else if (grille_temporaire[y][i] == ' ')
            {
                grille[y - 1][i] = -1; // remplace les espaces des quatres coins en -1
            }
        }
    }
}
/*********************************************************************************************************************/

/* Celle-ci comme son nom l'indique sert a afficher la grille dans le terminal*/

void affichage(int grille[LMAX][LMAX], int n)
{
    for (int ligne = 0; ligne < n; ligne++) // toujours par la ligne 1 et non 0 pour la raison expliquée plus haut
    {
        for (int col = 0; col < n; col++)
        {   if (grille[ligne][col]==-1)
        {
            printf("%c ", ' ');
        }
        else
            {printf("%d ", grille[ligne][col]);} // le reste est un parcours de matrice tout ce qu'il y a de plus classique...
        }
        printf("\n");
    }
}

/*********************************************************************************************************************/

void pov(int tab[LMAX], int n, int pdv[])
{
    int plg = tab[0];
    int j;
    pdv[0] = 1;
    pdv[1] = 1;
    for (j = 1; j < n; j++)
    {
        if (tab[j] > plg)
        {
            pdv[0] += 1;
            plg = tab[j];
        }
    }
    plg = tab[n - 1];
    for (j = n - 2; j >= 0; j--)
    {
        if (tab[j] > plg)
        {
            pdv[1] += 1;
            plg = tab[j];
        }
    }
}
/*********************************************************************************************************************/

bool absent_in_row(int k, int grille[LMAX][LMAX], int i, int n)
{
    for (int j = 1; j < n - 1; j++)
        if (grille[i][j] == k)
            return false;
    return true;
}
bool absent_in_column(int k, int grille[LMAX][LMAX], int j, int n)
{
    for (int i = 1; i < n - 1; i++)
        if (grille[i][j] == k)
            return false;
    return true;
}

/*********************************************************************************************************************/
void certs(int a, int b, int c, int d, int n, int grille[LMAX][LMAX], int i, int j) 
{
    int m = n - 2;
    int k, y;
    if (a == m && b == 1)
    {

        for (k = 1; k < n - 1; k++)
        {
            grille[i][k] = k;
        }
        m = n - 2;
    }
    else if (a == 1 && b == m)
    {
        for (k = 1; k < n - 1; k++)
        {
            grille[i][k] = m;
            m -= 1;
        }
        m = n - 2;
    }
    else if (a == 1)
    {
        grille[i][1] = m;
    }
    else if (b == 1)
    {
        grille[i][m] = m;
    }

    m = n - 2;
    if (c == m && d == 1)
    {

        for (y = 2; y < n; y++)
        {
            grille[y][j] = y - 1;
        }
    }
    else if (c == 1 && d == m)
    {
        for (y = 2; y < n; y++)
        {
            grille[y][j] = m;
            m -= 1;
        }
        m = n - 2;
    }
    else if (c == 1)
    {
        grille[1][j] = m;
    }
    else if (d == 1)
    {
        grille[m][j] = m;
    }
}
void traitement1(int grille[LMAX][LMAX], int n)
{
    int i, j;
    int a = 0, b = 0, c = 0, d = 0;
    for (i = 1; i < n; i++) // Horizontalement
    {
        a = grille[i][0];
        b = grille[i][n - 1];
        for (j = 1; j < n; j++) // Verticalement
        {
            c = grille[1][j];
            d = grille[n-1][j];
            certs(a, b, c, d, n, grille, i, j);
        }
    }
}

/*********************************************************************************************************************/
long factorielle(int n)
{
    if (n == 0)
        return 1;
    else
        return (n * factorielle(n - 1));
}

bool possible(int tab[], int a, int b, int size_tab)
{
    int pdv[] = {1, 1};
    pov(tab, size_tab, pdv);
    if (pdv[0] == a && pdv[1] == b)
    {
        return true;
    }
    else
    {
        return false;
    }
}
void possibilites(int comb[TMAX][TMAX], int pos[TMAX][TMAX], int size_tab, int a, int b)
{
    int i, j;
    int nb = factorielle(size_tab);
    int tab[LMAX];
    for (i = 0; i < nb; i++)
    {
        for (j = 0; j < size_tab; j++)
        {
            tab[j] = comb[i][j];
        }
        if (possible(tab, a, b, size_tab))
        {
            for (j = 0; j < size_tab; j++)
            {

                pos[i][j] = tab[j];
            }
        }
        else
        {
            for (j = 0; j < size_tab; j++)
            {

                pos[i][j] = 0;
            }
        }
    }
}

void permute(int tab[], int i, int j)
{
    int c;

    c = tab[i];
    tab[i] = tab[j];
    tab[j] = c;
}

void combin(int tab[], int i, int size_tab, int *k, int comb[TMAX][TMAX])
{
    int j;

    if (i == size_tab)
    {

        for (j = 0; j < size_tab; j++)
        {

            comb[*k][j] = tab[j];
        }

        (*k)++;
        
    }
    else
        for (j = i; j < size_tab; j++)
        {
            permute(tab, i, j);
            combin(tab, i + 1, size_tab, k, comb);
            permute(tab, i, j);
        }
}



/*********************************************************************************************************************/

void traitement2(int grille[LMAX][LMAX], int n, int comb[TMAX][TMAX], int temp[LMAX][LMAX])
{
    int j=0, z=0;
    int len = n - 2;
    int l = 0;
    int k, y;
    int nb;
    int pos[TMAX][TMAX];
    nb = factorielle(len);
    /*int ligne[LMAX];*/
    int tab[LMAX];
    int a = 0, b = 0; /* c = 0, d = 0*/
    for (z = 0; z < len; z++)

    {

        tab[z] = z + 1;
    }
    for (z = 0; z < n; z++)
    {
        for (j = 0; j < n; j++)
        {
            temp[z][j] = grille[z][j];
        }
    }
    

    combin(tab, 0, len, &l, comb);
    for (z = 1; z < n - 1; z++) // Horizontalement
    {
        a = grille[z][0];
        b = grille[z][n - 1];
        printf("a: %d  b: %d\n", a, b);
        /*for (j = 1; j < n; j++) // Verticalement
        {   ligne[j-1]=grille[i][j];
            c = grille[1][j];
            d = grille[n][j];

        }*/
        possibilites(comb, pos, len, a, b);
        for (k = 0; k < nb; k++)
        {
            for (y = 0; y < len; y++)
            {
                if (pos[k][y] != 0)
                {
                    printf("%d\t", pos[k][y]);
                }
            }
            printf("\n");
        }
        
    }
}