# Perpective




Présentation

Les projets doivent être réalisés par binômes (C'est-à-dire par groupe de DEUX étudiants).

Les projets devront être rendus le 13 avril 2022, avant 14 heures  (heure de Paris)
Tout jour de retard entamé coûte deux points sur la note (sur vingt).
Il faut fournir :

    1.une version électronique qui sera envoyée par email,
    2.un dossier imprimé sur papier qui sera donné à l'enseignant.
    Ces deux dossiers doivent comporter:
       1.un rapport présentant le travail, les choix faits et les difficultés rencontrées,
        2.un listing du programme, c'est-à-dire toutes les lignes du code,
        3.un mode d'emploi explicite et
        4.l'impression de traces d'exécution.
Les étudiants peuvent poser des questions par mail sur leur projet jusqu'au 7/4/22. Il est conseillé d'envoyer des versions préliminaires afin d'éviter les contresens.
